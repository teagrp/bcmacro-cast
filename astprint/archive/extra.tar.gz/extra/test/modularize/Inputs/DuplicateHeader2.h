// Same decl as in DuplicateHeader1.h.
typedef int TypeInt;
