// Exercise some anonymous type issues.

// Anonymous enum.
enum {
  Tag1
};

// Anonymous enum typedef.
typedef enum {
  Tag2
} AnonymousEnum;
