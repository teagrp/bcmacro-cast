void *bar(void *input);
void *glob2 = bar((void*)0x2345);
