int f_dso(int x, int y) {
  return 2 * x + y;
}

int f_replaced(int x, int y) {
  return x + y + 5;
}

int f_replacement(int x, int y) {
  return x + y + 6;
}
