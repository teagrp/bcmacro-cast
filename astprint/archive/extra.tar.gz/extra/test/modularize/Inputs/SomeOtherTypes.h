// Declare another type for the dependency check.
// This file dependent on SomeTypes.h being included first.

typedef TypeInt OtherTypeInt;
