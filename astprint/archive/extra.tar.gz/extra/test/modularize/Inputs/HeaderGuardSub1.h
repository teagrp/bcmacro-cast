#ifndef _HEADERGUARDSUB1_H_
#define _HEADERGUARDSUB1_H_
#include "HeaderGuardSubSub.h"
#include "HeaderGuardSubSubDefined.h"
#endif // _HEADERGUARDSUB1_H_
