void foo() {
  int *p = nullptr;
}
