// Declare a couple of functions - no modules problems.

void FuncOne();

int FuncTwo(int arg);

void FuncOverload(int arg) {}
void FuncOverload(char *arg) {}

namespace Namespace1 {
  void FuncNameSpace() {}
}

namespace Namespace2 {
  void FuncNameSpace() {}
}
