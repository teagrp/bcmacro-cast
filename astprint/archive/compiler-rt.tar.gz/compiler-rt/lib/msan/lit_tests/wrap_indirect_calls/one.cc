int f_other_object(int x, int y) {
  return x * y;
}
