void foo() {
  int *p = 0;
  int *k = nullptr;
}
