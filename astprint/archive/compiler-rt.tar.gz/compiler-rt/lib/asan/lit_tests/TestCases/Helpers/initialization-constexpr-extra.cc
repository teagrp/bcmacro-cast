// Constexpr:
int getCoolestInteger();
static int coolest_integer = getCoolestInteger();
